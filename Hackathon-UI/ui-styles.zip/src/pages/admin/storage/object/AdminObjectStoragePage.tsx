import { useState } from 'react'
import type { FormEvent } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import {
  getObjectStorages, createObjectStorage, deleteObjectStorage,
  startObjectStorage, stopObjectStorage, getFlavors, getUsers,
} from '../../../../api/api'
import type { ObjectStorage, Flavor } from '../../../../types/api'
import { StatusBadge } from '../../../../components/ui/StatusBadge'
import { CredentialsModal, type CredField } from '../../../../components/ui/CredentialsModal'
import { UserFilter } from '../../../../components/ui/UserFilter'
import s from '../../../shared.module.css'
import m from '../AdminStorage.module.css'

const DEFAULT_PROJECT_ID = '9d320322-31f5-48d5-ade8-43f1b03b5b59'
const ACTIVE_STATUSES = new Set(['pending', 'creating', 'pending-start', 'pending-stop'])

export function AdminObjectStoragePage() {
  const qc = useQueryClient()
  const [showCreate, setShowCreate]       = useState(false)
  const [credsFor, setCredsFor]           = useState<ObjectStorage | null>(null)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)
  const [selectedUserId, setSelectedUserId]   = useState<string | null>(null)

  const { data: storages = [], isLoading, isError } = useQuery<ObjectStorage[]>({
    queryKey: ['object-storages', selectedUserId],
    queryFn: () => getObjectStorages(selectedUserId),
    refetchInterval: (query) => {
      const data = query.state.data as ObjectStorage[] | undefined
      if (!data) return 5_000
      return data.some(s => ACTIVE_STATUSES.has(s.status)) ? 3_000 : 15_000
    },
  })

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: getUsers,
    staleTime: 60_000,
  })

  const startMut  = useMutation({ mutationFn: startObjectStorage,  onSuccess: () => { qc.invalidateQueries({ queryKey: ['object-storages'] }); toast.success('Object Storage запускается') },  onError: () => toast.error('Ошибка при запуске') })
  const stopMut   = useMutation({ mutationFn: stopObjectStorage,   onSuccess: () => { qc.invalidateQueries({ queryKey: ['object-storages'] }); toast.success('Object Storage останавливается') }, onError: () => toast.error('Ошибка при остановке') })
  const deleteMut = useMutation({
    mutationFn: deleteObjectStorage,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['object-storages'] }); setConfirmDeleteId(null); toast.success('Object Storage удалён') },
    onError: () => toast.error('Ошибка при удалении'),
  })

  const buildCredFields = (os: ObjectStorage): CredField[] => {
    const fields: CredField[] = []
    if (os.s3_endpoint)      fields.push({ label: 'S3 Endpoint',   value: os.s3_endpoint,      isLink: true })
    if (os.console_endpoint) fields.push({ label: 'Console UI',    value: os.console_endpoint, isLink: true })
    if (os.access_key)       fields.push({ label: 'Access Key',    value: os.access_key })
    if (os.secret_key)       fields.push({ label: 'Secret Key',    value: os.secret_key,       secret: true })
    if (os.bucket_name)      fields.push({ label: 'Default Bucket',value: os.bucket_name })
    if (os.s3_endpoint && os.access_key && os.secret_key)
      fields.push({ label: 'AWS CLI (пример)', value: `aws --endpoint-url ${os.s3_endpoint} s3 ls`, copyable: true })
    return fields
  }

  const hasPending = storages.some(s => ACTIVE_STATUSES.has(s.status))

  return (
    <div className={m.page}>
      <div className={s.pageHeader}>
        <div>
          <h1 className={s.pageTitle}>Object Storage</h1>
          <p className={s.pageSubtitle}>
            {storages.length} bucket{storages.length !== 1 ? 's' : ''}
            {hasPending && ' · auto-refresh 3s'}
          </p>
        </div>
        <button className={s.btnPrimary} onClick={() => setShowCreate(true)}>+ New Storage</button>
      </div>

      <UserFilter selectedUserId={selectedUserId} onChange={setSelectedUserId} />

      {isLoading && (
        <div className={s.stateBox}><div className={s.stateIcon}>📦</div><p className={s.stateText}>Loading object storages…</p></div>
      )}
      {isError && (
        <div className={s.stateBox}><p className={s.stateTextErr}>Failed to load. Эндпоинт /object-storages может быть ещё не готов.</p></div>
      )}
      {!isLoading && !isError && storages.length === 0 && (
        <div className={s.stateBox}>
          <div className={s.stateIcon}>📦</div>
          <p className={s.stateText}>No object storages yet</p>
          <button className={s.btnPrimary} style={{ marginTop: 12 }} onClick={() => setShowCreate(true)}>+ Create first storage</button>
        </div>
      )}

      {!isLoading && !isError && storages.length > 0 && (
        <div className={s.tableWrap}>
          <table className={s.table}>
            <thead>
              <tr>
                <th>Name</th><th>Пользователь</th><th>Status</th>
                <th>S3 Endpoint</th><th>Bucket</th><th>Size</th>
                <th>Created</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {storages.map(os => {
                const isActive     = ACTIVE_STATUSES.has(os.status)
                const isConfirming = confirmDeleteId === os.id
                const owner        = users.find(u => u.project?.id === os.project_id)
                return (
                  <tr key={os.id}>
                    <td className={s.cellBold}>{os.name}</td>
                    <td className={m.ownerCell}>{owner ? owner.email.split('@')[0] : '—'}</td>
                    <td><StatusBadge status={os.status} /></td>
                    <td className={s.cellMono}>
                      {os.s3_endpoint
                        ? <a href={os.s3_endpoint} target="_blank" rel="noreferrer" className={m.cellLink}>{os.s3_endpoint}</a>
                        : <span className={s.cellDim}>—</span>}
                    </td>
                    <td className={s.cellMono}>{os.bucket_name ?? '—'}</td>
                    <td className={s.cellDim}>{os.storage_limit_gb ? `${os.storage_limit_gb} GB` : '—'}</td>
                    <td className={s.cellDim}>{new Date(os.created_at).toLocaleString('ru-RU')}</td>
                    <td>
                      <div className={m.actionsCell}>
                        <button className={`${m.actionBtn} ${m.actionBtnAccess}`}
                          onClick={() => setCredsFor(os)} disabled={os.status !== 'running'}>
                          🔑 Access
                        </button>
                        {os.status === 'stopped' && (
                          <button className={`${m.actionBtn} ${m.actionBtnStart}`}
                            disabled={startMut.isPending} onClick={() => startMut.mutate(os.id)}>
                            {startMut.isPending ? '...' : '▶'}
                          </button>
                        )}
                        {os.status === 'running' && (
                          <button className={`${m.actionBtn} ${m.actionBtnStop}`}
                            disabled={stopMut.isPending} onClick={() => stopMut.mutate(os.id)}>
                            {stopMut.isPending ? '...' : '■'}
                          </button>
                        )}
                        {isConfirming ? (
                          <>
                            <button className={`${m.actionBtn} ${m.actionBtnConfirm}`}
                              disabled={deleteMut.isPending} onClick={() => deleteMut.mutate(os.id)}>
                              {deleteMut.isPending ? '...' : 'Да, удалить'}
                            </button>
                            <button className={`${m.actionBtn} ${m.actionBtnCancel}`}
                              onClick={() => setConfirmDeleteId(null)}>Отмена</button>
                          </>
                        ) : (
                          <button className={`${m.actionBtn} ${m.actionBtnDelete}`}
                            disabled={isActive} onClick={() => setConfirmDeleteId(os.id)}>
                            ✕ Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {showCreate && (
        <CreateObjectStorageModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['object-storages'] }) }}
        />
      )}
      {credsFor && (
        <CredentialsModal
          title={`${credsFor.name} — Access Credentials`}
          fields={buildCredFields(credsFor)}
          onClose={() => setCredsFor(null)}
        />
      )}
    </div>
  )
}

function CreateObjectStorageModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName]           = useState('')
  const [flavorId, setFlavorId]   = useState('')
  const [bucketName, setBucketName] = useState('')
  const [error, setError]         = useState('')

  const { data: flavors = [], isLoading: loadFlavors } = useQuery<Flavor[]>({
    queryKey: ['flavors', 'object_storage'],
    queryFn: () => getFlavors('object_storage'),
  })

  const mutation = useMutation({
    mutationFn: createObjectStorage,
    onSuccess: () => { toast.success('Object Storage создаётся...'); onCreated() },
    onError: (err: unknown) => {
      const msg = err instanceof Error ? err.message : 'Ошибка создания'
      setError(msg); toast.error(msg)
    },
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault(); setError('')
    if (!name.trim()) return setError('Введите имя хранилища')
    if (!flavorId)    return setError('Выберите конфигурацию')
    mutation.mutate({ name: name.trim(), project_id: DEFAULT_PROJECT_ID, flavor_id: flavorId, bucket_name: bucketName.trim() || name.trim() })
  }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2 className={m.modalTitle}>📦 Create Object Storage</h2>
        <p className={m.modalSubtitle}>
          S3-совместимое хранилище на базе MinIO. После создания получишь endpoint, access key и secret key.
        </p>
        <form className={m.form} onSubmit={handleSubmit}>
          <div>
            <label className="label">Имя хранилища</label>
            <input className="input" value={name} onChange={e => setName(e.target.value)}
              placeholder="e.g. production-files" autoFocus />
          </div>
          <div>
            <label className="label">
              Имя бакета&nbsp;
              <span className={m.labelNote}>(если пусто — будет как имя хранилища)</span>
            </label>
            <input className="input" value={bucketName} onChange={e => setBucketName(e.target.value)}
              placeholder="e.g. uploads" />
          </div>
          <div>
            <label className="label">Конфигурация (размер диска)</label>
            {loadFlavors
              ? <p className={s.stateText}>Загрузка конфигураций...</p>
              : flavors.length === 0
                ? <p className={s.stateTextErr}>Нет доступных конфигураций. Убедись что seed выполнен и бэкенд запущен.</p>
                : (
                  <div className={m.flavorList}>
                    {flavors.map(f => {
                      const ram = f.ram_mb >= 1024 ? `${f.ram_mb / 1024} GB` : `${f.ram_mb} MB`
                      return (
                        <button key={f.id} type="button"
                          className={`${m.flavorBtn} ${flavorId === f.id ? m.flavorBtnActive : ''}`}
                          onClick={() => setFlavorId(f.id)}>
                          <span className={m.flavorName}>{f.name}</span>
                          <span className={m.flavorSpec}>{f.cpu} vCPU · {ram} · {f.disk_gb} GB</span>
                          {flavorId === f.id && <span className={m.flavorCheck}>✓</span>}
                        </button>
                      )
                    })}
                  </div>
                )}
          </div>
          {error && <div className="form-error">⚠ {error}</div>}
          <div className={m.formFooter}>
            <button type="button" className="btn-secondary btn-sm" onClick={onClose}>Отмена</button>
            <button type="submit" disabled={mutation.isPending} className={s.btnPrimary}>
              {mutation.isPending ? 'Создаём...' : 'Создать →'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}