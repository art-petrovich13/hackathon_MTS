import { useState } from 'react'
import type { FormEvent } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import toast from 'react-hot-toast'
import {
  getFileStorages, createFileStorage, deleteFileStorage,
  startFileStorage, stopFileStorage, getFlavors,
} from '../../../../api/api'
import type { FileStorage, Flavor } from '../../../../types/api'
import { StatusBadge } from '../../../../components/ui/StatusBadge'
import { UserFilter } from '../../../../components/ui/UserFilter'
import { getUsers } from '../../../../api/api'
import s from '../../../shared.module.css'
import m from '../AdminStorage.module.css'

const DEFAULT_PROJECT_ID = '9d320322-31f5-48d5-ade8-43f1b03b5b59'
const ACTIVE_STATUSES = new Set(['pending', 'creating', 'pending-start', 'pending-stop'])

export function AdminFileStoragePage() {
  const qc = useQueryClient()
  const [showCreate, setShowCreate] = useState(false)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null)

  const { data: storages = [], isLoading, isError } = useQuery<FileStorage[]>({
    queryKey: ['file-storages', selectedUserId],
    queryFn: () => getFileStorages(selectedUserId),
    refetchInterval: (query) => {
      const data = query.state.data as FileStorage[] | undefined
      if (!data) return 5_000
      return data.some(s => ACTIVE_STATUSES.has(s.status)) ? 3_000 : 15_000
    },
  })

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: getUsers,
    staleTime: 60_000,
  })

  const deleteMut = useMutation({
    mutationFn: deleteFileStorage,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['file-storages'] }); setConfirmDeleteId(null); toast.success('File Storage удалён') },
    onError: () => toast.error('Ошибка при удалении'),
  })
  const startMut = useMutation({
    mutationFn: startFileStorage,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['file-storages'] }); toast.success('File Storage запускается...') },
    onError: () => toast.error('Ошибка запуска'),
  })
  const stopMut = useMutation({
    mutationFn: stopFileStorage,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['file-storages'] }); toast.success('File Storage останавливается...') },
    onError: () => toast.error('Ошибка остановки'),
  })

  const hasPending = storages.some(s => ACTIVE_STATUSES.has(s.status))

  return (
    <div className={m.page}>
      <div className={s.pageHeader}>
        <div>
          <h1 className={s.pageTitle}>File Storage</h1>
          <p className={s.pageSubtitle}>
            {storages.length} volume{storages.length !== 1 ? 's' : ''}
            {hasPending && ' · auto-refresh 3s'}
          </p>
        </div>
        <button className={s.btnPrimary} onClick={() => setShowCreate(true)}>+ New Storage</button>
      </div>

      <UserFilter selectedUserId={selectedUserId} onChange={setSelectedUserId} />

      {isLoading && (
        <div className={s.stateBox}>
          <div className={s.stateIcon}>💾</div>
          <p className={s.stateText}>Loading file storages…</p>
        </div>
      )}
      {isError && (
        <div className={s.stateBox}>
          <p className={s.stateTextErr}>Failed to load. Эндпоинт /file-storages может быть ещё не реализован.</p>
        </div>
      )}
      {!isLoading && !isError && storages.length === 0 && (
        <div className={s.stateBox}>
          <div className={s.stateIcon}>💾</div>
          <p className={s.stateText}>No file storages yet</p>
          <button className={s.btnPrimary} style={{ marginTop: 12 }} onClick={() => setShowCreate(true)}>
            + Create first storage
          </button>
        </div>
      )}

      {!isLoading && !isError && storages.length > 0 && (
        <div className={s.tableWrap}>
          <table className={s.table}>
            <thead>
              <tr>
                <th>Name</th><th>Пользователь</th><th>Status</th>
                <th>NFS Endpoint</th><th>Volume</th><th>Size</th>
                <th>Created</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {storages.map(fs => {
                const isActive    = ACTIVE_STATUSES.has(fs.status)
                const isConfirming = confirmDeleteId === fs.id
                const owner       = users.find(u => u.project?.id === fs.project_id)
                return (
                  <tr key={fs.id}>
                    <td className={s.cellBold}>{fs.name}</td>
                    <td className={m.ownerCell}>{owner ? owner.email.split('@')[0] : '—'}</td>
                    <td><StatusBadge status={fs.status} /></td>
                    <td className={s.cellMono}>
                      {fs.nfs_endpoint
                        ? <a href={fs.nfs_endpoint} target="_blank" rel="noreferrer" className={m.cellLink}>{fs.nfs_endpoint}</a>
                        : <span className={s.cellDim}>—</span>}
                    </td>
                    <td className={s.cellMono}>{fs.volume_name ?? '—'}</td>
                    <td className={s.cellDim}>{fs.size_gb ? `${fs.size_gb} GB` : '—'}</td>
                    <td className={s.cellDim}>{new Date(fs.created_at).toLocaleString('ru-RU')}</td>
                    <td>
                      <div className={m.actionsCell}>
                        {fs.status === 'stopped' && (
                          <button className={`${m.actionBtn} ${m.actionBtnStart}`}
                            disabled={startMut.isPending} onClick={() => startMut.mutate(fs.id)}>▶</button>
                        )}
                        {fs.status === 'running' && (
                          <button className={`${m.actionBtn} ${m.actionBtnStop}`}
                            disabled={stopMut.isPending} onClick={() => stopMut.mutate(fs.id)}>■</button>
                        )}
                        {isConfirming ? (
                          <>
                            <button className={`${m.actionBtn} ${m.actionBtnConfirm}`}
                              disabled={deleteMut.isPending} onClick={() => deleteMut.mutate(fs.id)}>
                              {deleteMut.isPending ? '...' : 'Да, удалить'}
                            </button>
                            <button className={`${m.actionBtn} ${m.actionBtnCancel}`}
                              onClick={() => setConfirmDeleteId(null)}>Отмена</button>
                          </>
                        ) : (
                          <button className={`${m.actionBtn} ${m.actionBtnDelete}`}
                            disabled={isActive} onClick={() => setConfirmDeleteId(fs.id)}>
                            ✕ Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {showCreate && (
        <CreateFileStorageModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['file-storages'] }) }}
        />
      )}
    </div>
  )
}

function CreateFileStorageModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName]         = useState('')
  const [flavorId, setFlavorId] = useState('')
  const [error, setError]       = useState('')

  const { data: flavors = [], isLoading: loadFlavors } = useQuery<Flavor[]>({
    queryKey: ['flavors', 'file_storage'],
    queryFn: () => getFlavors('file_storage'),
  })

  const mutation = useMutation({
    mutationFn: createFileStorage,
    onSuccess: () => { toast.success('File Storage создаётся...'); onCreated() },
    onError: (err: unknown) => {
      const msg = err instanceof Error ? err.message : 'Ошибка создания'
      setError(msg); toast.error(msg)
    },
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault(); setError('')
    if (!name.trim()) return setError('Введите имя хранилища')
    if (!flavorId)    return setError('Выберите конфигурацию')
    mutation.mutate({ name: name.trim(), project_id: DEFAULT_PROJECT_ID, flavor_id: flavorId })
  }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <h2 className={m.modalTitle}>💾 Create File Storage</h2>
        <p className={m.modalSubtitle}>
          Docker volume с NFS-доступом. Подходит для шаринга файлов между контейнерами.
        </p>
        <form className={m.form} onSubmit={handleSubmit}>
          <div>
            <label className="label">Имя хранилища</label>
            <input className="input" value={name} onChange={e => setName(e.target.value)}
              placeholder="e.g. shared-assets" autoFocus />
          </div>
          <div>
            <label className="label">Размер</label>
            {loadFlavors
              ? <p className={s.stateText}>Загрузка...</p>
              : flavors.length === 0
                ? <p className={s.stateTextErr}>Нет доступных конфигураций</p>
                : (
                  <div className={m.flavorList}>
                    {flavors.map(f => (
                      <button key={f.id} type="button"
                        className={`${m.flavorBtn} ${flavorId === f.id ? m.flavorBtnActive : ''}`}
                        onClick={() => setFlavorId(f.id)}>
                        <span className={m.flavorName}>{f.name}</span>
                        <span className={m.flavorSpec}>{f.disk_gb} GB</span>
                        {flavorId === f.id && <span className={m.flavorCheck}>✓</span>}
                      </button>
                    ))}
                  </div>
                )}
          </div>
          {error && <div className="form-error">⚠ {error}</div>}
          <div className={m.formFooter}>
            <button type="button" className="btn-secondary btn-sm" onClick={onClose}>Отмена</button>
            <button type="submit" disabled={mutation.isPending} className={s.btnPrimary}>
              {mutation.isPending ? 'Создаём...' : 'Создать →'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}